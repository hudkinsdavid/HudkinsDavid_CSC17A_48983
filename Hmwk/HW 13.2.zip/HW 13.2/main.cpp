/*
 * main.cpp
 *
 *  Created on: Nov 18, 2015
 *      Author: David Hudkins II
 *  Purpose: This program uses a class Employee to display info regarding
 *  	said employee.
 */

#include "Employee.h"

int main(){
	//Initialize classes information with constructors
	Employee susan("Susan Meyers", 48499, "Accounting", "Vice President");
	Employee mark("Mark Jones", 39119, "IT", "Programmer");
	Employee joy("Joy Rogers", 81774, "Manufacturing", "Engineer");

	//Show each instantiation of Employee contents
	susan.shwInfo();
	mark.shwInfo();
	joy.shwInfo();

	return 0;
}


