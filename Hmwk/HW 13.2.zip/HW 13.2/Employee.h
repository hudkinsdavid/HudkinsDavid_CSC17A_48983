/*
 * Employee.h
 *
 *  Created on: Nov 18, 2015
 *      Author: David Hudkins II
 *  Purpose: Defines class Employee to utilize a constructor to define
 *  	information regarding an employee of a company and then displays
 *  	that information.
 */

//System Libraries
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

#ifndef EMPLOYEE_H_
#define EMPLOYEE_H_

//Employee Class
class Employee{
private:
	string name;		//Employee name
	int idNumber;		//Employee id number
	string department;	//Department that employee works in
	string position;	//Employee's position
public:
	Employee();								//Default constructor
	Employee(string, int, string, string);	//Constructor that mutates
	Employee(string, int);					//Constructor that mutates
	void getInfo();							//Get employee information
	void shwInfo()const;					//Show employee information
};

#endif /* EMPLOYEE_H_ */
