/*
 * Employee.cpp
 *
 *  Created on: Nov 18, 2015
 *      Author: David Hudkins II
 *  Purpose: Defines member functions of class Employee
 */

#include "Employee.h"

Employee::Employee(){
	//Initializes member variables
	name = "";
	idNumber = 0;
	department = "";
	position = "";
}

Employee::Employee(string who, int id, string dept, string pos){
	//Initializes member variables with parameters
	name = who;
	idNumber = id;
	department = dept;
	position = pos;
}

Employee::Employee(string who, int id){
	//Initializes member variables to default as well as with parameters
	name = who;
	idNumber = id;
	department = "";
	position = "";
}

void Employee::getInfo(){
	//Prompt user to input employees information
	cout << "\nEnter employee name: ";
	cin >> name;							//INPUT- Employee name
	cout << "\nEnter employee id number: ";
	cin >> idNumber;						//INPUT- Employee id number
	cout << "\nEnter department: ";
	cin >> department;						//INPUT- Department employee works in
	cout << "\nEnter position: ";
	cin >> position;						//INPUT- Employee's postion
	cout << endl << endl;
}

void Employee::shwInfo()const{
	//Show information about the employee with formatting
	cout << left << setw(20) << "Name" << setw(20) << "ID Number" << setw(20) << "Department";
	cout << setw(20) << "Position" << endl << "--------------------------";
	cout << "------------------------------------------------------------";
	cout << endl << setw(20) << name << setw(20) << idNumber << setw(20) << department;
	cout << setw(20) << position << endl << endl << endl;
}
