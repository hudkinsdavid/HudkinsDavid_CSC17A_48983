/*
 * Car.h
 *
 *  Created on: Nov 18, 2015
 *      Author: David Hudkins II
 *  Purpose: Creates a class Car that utitlizes a constructor that accepts
 *  	a vehicles year make and manufacture make as parameters. Also uses
 *  	member functions to increment and decrement vehicle speed. Then
 *  	displays the vehicle information.
 */

//System Libraries
#include <string>
#include <iostream>
using namespace std;

#ifndef CAR_H_
#define CAR_H_

//Car class
class Car{
private:
	int yearModel;		//Year of car
	string make;		//Manufacture make of car
	int speed;			//Speed of car currently
public:
	Car();				//Default constructor
	Car(int, string);	//Constructor with parameters
	void accelerate();	//Accelerate vehicle
	void brake();		//Brake vehicle
	void shwCar();		//Show vehicle information
};

#endif /* CAR_H_ */
