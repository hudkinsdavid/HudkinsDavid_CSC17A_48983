/*
 * Car.cpp
 *
 *  Created on: Nov 18, 2015
 *      Author: David Hudkins II
 *  Purpose: Defines member functions of class Car
 */

//User Libraries
#include "Car.h"

Car::Car(){
	//Initializes member variables
	yearModel=0;
	make="";
	speed=0;
}

Car::Car(int yr, string mk){
	//Initializes member variables either to default or to parameters
	yearModel = yr;
	make = mk;
	speed = 0;
}

void Car::accelerate(){
	speed+=5;							//Increment cars speed
	cout<<"Speed: "<<speed<<endl<<endl;	//Show cars speed
}
void Car::brake(){
	speed-=5;							//Decrement cars speed
	cout<<"Speed: "<<speed<<endl<<endl;	//Show cars speed
}

void Car::shwCar(){
	//Show vehicle information
	cout<<"Year: "<<yearModel<<endl<<"Make: "<<make<<endl<<"Speed: "<<speed;
}
