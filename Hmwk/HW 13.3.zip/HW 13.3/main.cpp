/*
 * main.cpp
 *
 *  Created on: Nov 18, 2015
 *      Author: David
 */

//User Libraries
#include "Car.h"

//Execute program
int main(){
	//Instantiation of Car class
	Car myCar(1998, "Buick");

	//Call accelerate function 5 times
	myCar.accelerate();
	myCar.accelerate();
	myCar.accelerate();
	myCar.accelerate();
	myCar.accelerate();

	//Call brake function 5 times
	myCar.brake();
	myCar.brake();
	myCar.brake();
	myCar.brake();
	myCar.brake();

	//Display attributes of class
	myCar.shwCar();

	return 0;
}
