/*
 * main.cpp
 *
 *  Created on: Nov 18, 2015
 *      Author: David Hudkins II
 *  Purpose: Using a class Circle, prompt user to input radius and display
 *  	the area, diameter, and circumference of a circle with that radius.
 */

//User Libraries
#include "Circle.h"

//Execute Program
int main(){
	float rad;							//INPUT- radius of circle
	float diam;							//Diameter of circle
	float area;							//Area of circle
	float circmf;						//Circumference of circle
	Circle tstCirc;						//Instantiation of class Circle

	tstCirc.setRadius();				//Get radius from user
	rad=tstCirc.getRadius();			//Assign radius
	diam=tstCirc.getDiameter();			//Assign diameter
	circmf=tstCirc.getCircumference();	//Assign circumference
	area=tstCirc.getArea();				//Assign area

	//Display circle statistics
	cout<<"Radius: "<<rad<<endl<<"Diameter: "<<diam<<endl<<"Area: "<<area;
	cout<<endl<<"Circumference: "<<circmf<<endl;

	//Terminate Program
	return 0;
}
