/*
 * Circle.cpp
 *
 *  Created on: Nov 18, 2015
 *      Author: David Hudkins
 *  Purpose: Defines all member functions of the Circle class
 */

//User Libraries
#include "Circle.h"

Circle::Circle(){
	//Initialize all member variables
	radius=0.0;
}

Circle::Circle(float rad){
	radius=rad;					//Set radius to supplied parameter
}

void Circle::setRadius(){
	//Prompt user to enter radius
	cout<<"Enter the radius: ";
	cin>>radius; cout<<endl;	//INPUT- radius of a circle
}

float Circle::getRadius()const{
	return radius;				//Returns value of member variable radius
}

float Circle::getArea()const{
	float A=pi*radius*radius;	//PROCESS- determine area of a circle with given radius
	return A;					//Return area
}

float Circle::getDiameter()const{
	float D=radius*2;			//PROCESS- determine diameter of a circle with given radius
	return D;					//Return diameter
}

float Circle::getCircumference()const{
	float C=2*pi*radius;		//PROCESS- determine circumference of a circle with given radius
	return C;					//Return circumference
}
