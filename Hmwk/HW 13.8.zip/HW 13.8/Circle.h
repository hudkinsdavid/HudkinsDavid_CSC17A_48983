/*
 * Circle.h
 *
 *  Created on: Nov 18, 2015
 *      Author: David Hudkins II
 *  Purpose: Creates a class Circle and allows that class to accept a
 *  	radius of a circle and supply the area, diameter, and circumference
 *  	of that circle.
 */

//System Libraries
#include <iostream>
using namespace std;

#ifndef CIRCLE_H_
#define CIRCLE_H_

class Circle{
private:
	float radius;					//INPUT- radius of a circle
	const static float pi=3.14159;	//ratio of circumference to diameter
public:
	Circle();						//Default constructor
	Circle(float);					//Constructor that accepts parameter for radius
	void setRadius();				//Sets the radius through console input
	float getRadius()const;			//Returns the radius
	float getArea()const;			//Calculates area of circle
	float getDiameter()const;		//Calculates diameter of circle
	float getCircumference()const;	//Calculates circumference of circle
};

#endif /* CIRCLE_H_ */
