/*
 * FeetInches.cpp
 *
 *  Created on: Nov 23, 2015
 *      Author: David Hudkins II
 *  Purpose: Define member functions for the FeetInches class
 */

//User Libraries
#include "FeetInches.h"

	void FeetInches::simplify(){//Simplify quantities into feet and inches
		if(inches>=12){			//Execute if inches greater than 12
			feet+=(inches/12);	//Feet in inches
			inches=inches%12;	//Leftover inches
		}
	}

	FeetInches::FeetInches(){			//Initialize attributes to zero
		feet=0;
		inches=0;
	}

	bool FeetInches::operator <=(const FeetInches &right){	//Overload <= operator
		bool test;			//Flag for less than or equal to validity

		//Execute if feet are <= supplied comparison
		if(feet<=right.feet)
			test=true;		//Set flag to true
		//Execute if feet are == and inches are > than supplied comparison
		else if(feet==right.feet && inches<right.inches)
			test=true;		//Set flag to true
		//Execute if feet and inches are == to supplied comparison
		else if(feet==right.feet && inches==right.inches)
			test=true;		//Set flag to true
		//Execute if measurement are not <= supplied comparison
		else
			test=false;		//Set flag to false

		return test;		//Return flag
	}

	bool FeetInches::operator >=(const FeetInches &right){	//Overload >= operator
		bool test;			//Flag for greater than or equal to comparison

		//Execute if feet are >= supplied comparison
		if(feet>=right.feet)
			test=true;		//Set flag to true
		//Execute if feet are == and inches are > than supplied comparison
		else if(feet==right.feet && inches>right.inches)
			test=true;		//Set flag to true
		//Execute if feet and inches are == to supplied comparison
		else if(feet==right.feet && inches==right.inches)
			test=true;		//Set flag to true
		//Execute if measurements are not >= supplied comparison
		else
			test=false;		//Set flag to false

		return test;		//Return flag
	}

	bool FeetInches::operator !=(const FeetInches &right){	//Overload != operator
		bool test;			//Flag for not equal to supplied comparison

		//Execute if feet and inches are equal to supplied comparison
		if(feet==right.feet && inches==right.inches)
			test=false;		//Set flag to false
		//Execute if feet and inches are not equal to supplied comparison
		else
			test=true;		//Set flag to true

		return test;		//Return flag
	}
