/*
 * FeetInches.h
 *
 *  Created on: Nov 23, 2015
 *      Author: David Hudkins II
 *  Purpose: Modifies the FeetInches class discussed in chapter 14 of Gaddis
 *  	to have operators <= >= and != overloaded
 */

//System Libraries
#include <iostream>
using namespace std;

#ifndef FEETINCHES_H_
#define FEETINCHES_H_

class FeetInches{
private:
	int feet;									//Number of feet
	int inches;									//Number of inches
	void simplify();							//Defined in FeetInches.cpp
public:
	FeetInches();								//Default Constructor

	//Mutator Functions
	void setFeet(int f){feet=f;}				//Set number of feet
	void setInches(int i){inches=i;simplify();}	//Set number of inches

	//Accessor Functions
	int getFeet() const{return feet;}	 		//Access feet
	int getInches() const{return inches;}		//Access inches

	//Operator Overload
	bool operator <=(const FeetInches &right);	//Overload less than or equal to
	bool operator >=(const FeetInches &right);	//Overload greater than or equal to
	bool operator !=(const FeetInches &right);	//Overload not equal to
};

#endif /* FEETINCHES_H_ */
