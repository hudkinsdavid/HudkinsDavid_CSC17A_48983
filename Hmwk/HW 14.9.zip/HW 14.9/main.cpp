/*
 * main.cpp
 *
 *  Created on: Nov 23, 2015
 *      Author: David Hudkins
 *  Purpose: Demonstrates FeetInches class modified to overload the <= >= and !=
 *  	operators.
 */

//User Libraries
#include "FeetInches.h"

//Execute Program
int main(){
	//Declare Variables
	FeetInches user;		//Instantiation of FeetInches class
	FeetInches test;		//Instantiation of FeetInches class
	int ft=16;				//Number of feet
	int in=16;				//Number of inches
	int fts=17;				//Number of feet
	int ins=16;				//Number of inches
	int testy;				//Holds integer for testing output

	//Assign feet and inches to both class instantiations
	user.setFeet(ft);
	user.setInches(in);
	test.setFeet(fts);
	test.setInches(ins);

	//Gets and displays information regarding feet and inches held in class instantiations
	testy=user.getFeet();
	cout<<"Feet 1: "<<testy<<endl;
	testy=user.getInches();
	cout<<"Inches 1: "<<testy<<endl;
	testy=test.getFeet();
	cout<<"Feet 2: "<<testy<<endl;
	testy=test.getInches();
	cout<<"Inches 2: "<<testy<<endl;

	//Execute if operator overload on >= works properly
	if(test>=user)
		cout<<"This program works"<<endl;
	//Notification of bad code
	else
		cout<<"This program sucks"<<endl;

	//Execute if operator overload on <= works properly
	if(user<=test)
		cout<<"This program works again"<<endl;
	//Notification of bad code
	else
		cout<<"This program still sucks"<<endl;

	//Execute if operator overload on != works properly
	if(test!=user)
		cout<<"This program is fantastic!"<<endl;
	//Notification of bad code
	else
		cout<<"Don't quit your day job 'programmer'"<<endl;

	//Terminate Program
	return 0;
}

