/*
 * main.cpp
 *
 *  Created on: Nov 23, 2015
 *      Author: David Hudkins II
 *  Purpose: Show capabilities of user defined class Month.
 */

//User Libraries
#include "Month.h"

//Execute Program
int main(){
	Month userMon("January");	//Month class instatiation

	userMon.getMnth();			//Get month info

	userMon++;					//Increment month postfix

	userMon.getMnth();			//Get month info

	++userMon;					//Increment month prefix

	userMon.getMnth();			//Get month info

	userMon--;					//Decrement month postfix

	userMon.getMnth();			//Get month info

	--userMon;					//Decrement month prefix

	userMon.getMnth();			//Get month info

	--userMon;					//Decrement month prefix

	userMon.getMnth();			//Get month info

	userMon++;					//Increment month postfix

	userMon.getMnth();			//Get month info

	//Terminate Program
	return 0;
}


