/*
 * Month.h
 *
 *  Created on: Nov 23, 2015
 *      Author: David Hudkins II
 *  Purpose: Create class Month to hold month name and number and perform
 *  	increment and decrement operations on months.
 */

//System Libraries
#include <iostream>
#include <string>
using namespace std;

#ifndef MONTH_H_
#define MONTH_H_

//Month class
class Month{
private:
	string name;			//Month name
	int monthNumber;		//Month number
public:
	Month();				//Default Constructor
	Month(int);				//Parameterized Constructor
	Month(string);			//Parameterized Constructor
	void setMnth();			//Set month
	void getMnth() const;	//Get month
	Month operator ++();	//++ prefix overload
	Month operator --();	//-- prefix overload
	Month operator ++(int);	//++ postfix overload
	Month operator --(int);	//-- postfix overload
};

#endif /* MONTH_H_ */
