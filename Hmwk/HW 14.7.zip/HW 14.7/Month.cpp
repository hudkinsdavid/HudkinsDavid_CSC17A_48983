/*
 * Month.cpp
 *
 *  Created on: Nov 23, 2015
 *      Author: David Hudkins II
 *  Purpose: Define member functions of class Month
 */

//User Libraries
#include "Month.h"

#ifndef MONTH_CPP_
#define MONTH_CPP_

Month::Month(){				//Initialize all attributes
	name="January";
	monthNumber=1;
}

Month::Month(int mnthNum){	//Initialize month name according to number input
	monthNumber=mnthNum;	//Assign month number input from the console

	//Initialize month name according to number input
	switch(mnthNum){
	case 1:
		name="January";
		break;
	case 2:
		name="February";
		break;
	case 3:
		name="March";
		break;
	case 4:
		name="April";
		break;
	case 5:
		name="May";
		break;
	case 6:
		name="June";
		break;
	case 7:
		name="July";
		break;
	case 8:
		name="August";
		break;
	case 9:
		name="September";
		break;
	case 10:
		name="October";
		break;
	case 11:
		name="November";
		break;
	case 12:
		name="December";
		break;
	default:
		cout<<"Invalid month entered";
	}
}

Month::Month(string mnthNam){	//Initialize month number according to name input
	name=mnthNam;				//Assign month name input from the console

	//Initialize month number according to name input
	if(name=="January")
		monthNumber=1;
	else if(name=="February")
		monthNumber=2;
	else if(name=="March")
		monthNumber=3;
	else if(name=="April")
		monthNumber=4;
	else if(name=="May")
		monthNumber=5;
	else if(name=="June")
		monthNumber=6;
	else if(name=="July")
		monthNumber=7;
	else if(name=="August")
		monthNumber=8;
	else if(name=="September")
		monthNumber=9;
	else if(name=="October")
		monthNumber=10;
	else if(name=="November")
		monthNumber=11;
	else if(name=="December")
		monthNumber=12;
	else
		cout<<"Invalid month entered";
}

void Month::setMnth(){		//Prompt user to input month name and number
	cout<<"Enter the month name: ";
	cin>>name;				//INPUT- Month name
	cout<<"\nEnter the month's numerical value: ";
	cin >>monthNumber;		//INPUT- Month number
	cout<<endl<<endl;
}

void Month::getMnth() const{//Display month name and number currently
	cout<<"Month: "<<name<<endl<<"Month Number: "<<monthNumber<<endl;
}

Month Month::operator ++(){	//Increment month name and number prefix
	if(monthNumber<12)		//Execute not december
		++monthNumber;		//Increment month prefix
	else					//Execute otherwise
		monthNumber=1;		//Month set to january

	//Set month name according to number
	switch(monthNumber){
	case 1:
		name="January";
		break;
	case 2:
		name="February";
		break;
	case 3:
		name="March";
		break;
	case 4:
		name="April";
		break;
	case 5:
		name="May";
		break;
	case 6:
		name="June";
		break;
	case 7:
		name="July";
		break;
	case 8:
		name="August";
		break;
	case 9:
		name="September";
		break;
	case 10:
		name="October";
		break;
	case 11:
		name="November";
		break;
	case 12:
		name="December";
		break;
	default:
		cout<<"Invalid month entered";
	}
	return *this;	//Return pointer
}

Month Month::operator --(){	//Decrement month name and number prefix
	if(monthNumber>1)		//Execute if not january
		--monthNumber;		//Decrement month prefix
	else					//Execute otherwise
		monthNumber=12;		//Set month to december

	//Set month name according to number
	switch(monthNumber){
	case 1:
		name="January";
		break;
	case 2:
		name="February";
		break;
	case 3:
		name="March";
		break;
	case 4:
		name="April";
		break;
	case 5:
		name="May";
		break;
	case 6:
		name="June";
		break;
	case 7:
		name="July";
		break;
	case 8:
		name="August";
		break;
	case 9:
		name="September";
		break;
	case 10:
		name="October";
		break;
	case 11:
		name="November";
		break;
	case 12:
		name="December";
		break;
	default:
		cout<<"Invalid month entered";
	}

	return *this;		//Return pointer
}

Month Month::operator ++(int){	//Increment month name and number postfix
	Month temp(monthNumber);	//Copy class

	if(monthNumber<12)			//Execute if not december
		monthNumber++;			//Increment month postfix
	else						//Execute otherwise
		monthNumber=1;			//Set month to january

	//Set month name according to number
	switch(monthNumber){
	case 1:
		name="January";
		break;
	case 2:
		name="February";
		break;
	case 3:
		name="March";
		break;
	case 4:
		name="April";
		break;
	case 5:
		name="May";
		break;
	case 6:
		name="June";
		break;
	case 7:
		name="July";
		break;
	case 8:
		name="August";
		break;
	case 9:
		name="September";
		break;
	case 10:
		name="October";
		break;
	case 11:
		name="November";
		break;
	case 12:
		name="December";
		break;
	default:
		cout<<"Invalid month entered";
	}
	return temp;	//Return copy of class
}

Month Month::operator --(int){	//Decrement month name and number postfix
	Month temp(monthNumber);	//Create copy of class

	if(monthNumber>1)			//Execute if not january
		monthNumber--;			//Decrement month postfix
	else						//Execute otherwise
		monthNumber=12;			//Set month to december

	//Set month name according to number
	switch(monthNumber){
	case 1:
		name="January";
		break;
	case 2:
		name="February";
		break;
	case 3:
		name="March";
		break;
	case 4:
		name="April";
		break;
	case 5:
		name="May";
		break;
	case 6:
		name="June";
		break;
	case 7:
		name="July";
		break;
	case 8:
		name="August";
		break;
	case 9:
		name="September";
		break;
	case 10:
		name="October";
		break;
	case 11:
		name="November";
		break;
	case 12:
		name="December";
		break;
	default:
		cout<<"Invalid month entered";
	}

	return temp;		//Return copy of class
}

#endif /* MONTH_CPP_ */
