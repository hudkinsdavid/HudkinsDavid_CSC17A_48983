/*
 * TestScores.cpp
 *
 *  Created on: Nov 18, 2015
 *      Author: David Hudkins II
 *  Purpose: Defines member functions of TestScores class
 */

//User Libraries
#include "TestScores.h"

TestScores::TestScores(){
	score1=0.0;
	score2=0.0;
	score3=0.0;
}

void TestScores::getScrs(){
	//Prompt user to input test scores
	cout<<"Enter three test scores separated by whitespace: ";
	cin>>score1;		//INPUT- score 1
	cin>>score2;		//INPUT- score 2
	cin>>score3;		//INPUT- score 3
}

void TestScores::shwScrs()const{
	//Display contents of class to user and score average
	cout<<"The scores were "<<score1<<" "<<score2<<" "<<score3<<endl;
	cout<<"With an average score of "<<(score1+score2+score3)/3;
}
