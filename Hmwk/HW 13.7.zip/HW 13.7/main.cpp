/*
 * main.cpp
 *
 *  Created on: Nov 18, 2015
 *      Author: David Hudkins II
 *  Purpose: Uses a class name TestScores to get and display test scores
 *  	as well as the average test score.
 */

//User Libraries
#include "TestScores.h"

//Execute Program
int main(){
	//Instantiation of TestScores class
	TestScores average;

	//Get test scores
	average.getScrs();
	//Show test scores and their average
	average.shwScrs();

	//Terminate program
	return 0;
}
