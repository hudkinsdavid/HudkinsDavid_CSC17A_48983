/*
 * TestScores.h
 *
 *  Created on: Nov 18, 2015
 *      Author: David Hudkins II
 *  Purpose: Defines a class named TestScores to handle test scores as
 *  	user input.
 */
#include <iostream>
using namespace std;

#ifndef TESTSCORES_H_
#define TESTSCORES_H_

class TestScores{
private:
	float score1;			//Test score 1
	float score2;			//Test score 1
	float score3;			//Test score 1
public:
	TestScores();			//Default constructor
	void getScrs();			//Mutator for scores
	void shwScrs()const;	//Accessor for scores
};



#endif /* TESTSCORES_H_ */
