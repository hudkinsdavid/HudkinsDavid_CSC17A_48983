/*
 * FeetInches.cpp
 *
 *  Created on: Nov 23, 2015
 *      Author: David Hudkins II
 *  Purpose: Define member functions for the FeetInches class
 */

//User Libraries
#include "FeetInches.h"

	void FeetInches::simplify(){//Simplify quantities into feet and inches
		if(inches>=12){			//Execute if inches greater than 12
			feet+=(inches/12);	//Feet in inches
			inches=inches%12;	//Leftover inches
		}
	}

	FeetInches::FeetInches(){			//Initialize attributes to zero
		feet=0.0;
		inches=0;
	}

	void FeetInches::setMeas(){			//Request size in inches from console
		cout<<"How many inches is the measurement: ";
		cin>>inches;					//INPUT- size in inches
		simplify();						//Call simplify function to set feet and inches
	}
