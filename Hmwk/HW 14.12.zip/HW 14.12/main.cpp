/*
 * main.cpp
 *
 *  Created on: Nov 23, 2015
 *      Author: David Hudkins II
 *  Purpose: Using the LandTract class, define two objects, supply the
 *  	measurements of the objects, get the area of the objects, and then
 *  	compare them to see if they are the same size.
 */

//User Libraries
#include "LandTract.h"

//Execute Program
int main(){
	//Declare Variables
	LandTract mine;			//Instantiation of LandTract class
	LandTract yours;		//Instantiation of LandTract class
	float area1;			//First area
	float area2;			//Second area

	//Get measurements for mine
	mine.setlngth();		//Set the length of mine
	mine.setwdth();			//Set the width of mine
	area1=mine.getArea();	//Set the area of mine

	//Get measurements for yours
	yours.setlngth();		//Set the length of yours
	yours.setwdth();		//Set the width of yours
	area2=yours.getArea();	//Set the area of yours

	//Display areas one and two
	cout<<"Area 1: "<<area1<<" square feet"<<endl;
	cout<<"Area 2: "<<area2<<" square feet"<<endl;

	//Execute if areas are equal
	if(area1==area2)
		cout<<"The Land Tracts are the same size.";
	//Execute if areas are not equal
	else
		cout<<"The land tracts are of different sizes.";

	//Terminate program
	return 0;
}


