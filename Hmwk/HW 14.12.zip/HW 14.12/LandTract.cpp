/*
 * LandTract.cpp
 *
 *  Created on: Nov 23, 2015
 *      Author: David Hudkins II
 *  Purpose: Define member functions of LandTract class.
 */

#include "LandTract.h"

	LandTract::LandTract(){		//Initialize all attributes of class to zero
		lngth=0.0;
		wdth=0.0;
		area=0.0;
	}

	void LandTract::setlngth(){	//Get length of object
		cout<<"Length-"<<endl;
		length.setMeas();		//Use FeetInches class member function to set length
	}
	void LandTract::setwdth(){	//Get width of object
		cout<<"Width-"<<endl;
		width.setMeas();		//Use FeetInches class member function to set width
	}

	float LandTract::getArea(){	//Get area of object in square feet
		//Set length to feet from information stored in the length object
		lngth=(length.getFeet()+(static_cast<float>(length.getInches())/12));

		//Set width to feet from information stored in the width object
		wdth=(width.getFeet()+(static_cast<float>(width.getInches())/12));

		//Calculate area of object
		area=lngth*wdth;		//PROCESS- area of object

		return area;			//Return area of object
	}

