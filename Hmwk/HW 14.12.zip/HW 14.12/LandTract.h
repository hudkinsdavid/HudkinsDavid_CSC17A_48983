/*
 * LandTract.h
 *
 *  Created on: Nov 23, 2015
 *      Author: David Hudkins II
 *  Purpose: Get the length and width of a land tract using the FeetInches
 *  	class to store the values. Then gets the area of the object from
 *  	those two instantiations.
 */

#include "FeetInches.h"

#ifndef LANDTRACT_H_
#define LANDTRACT_H_

class LandTract{
private:
	float lngth;			//Length in feet
	float wdth;				//Width in feet
	float area;				//Area in square feet
	FeetInches length;		//Instantiation of class FeetInches
	FeetInches width;		//Instantiation of class FeetInches
public:
	LandTract();			//Default constructor
	//Mutator Functions
	void setwdth();			//Set width of object
	void setlngth();		//Set length of object
	float getArea();		//Get area of object
};



#endif /* LANDTRACT_H_ */
