/*
 * FeetInches.h
 *
 *  Created on: Nov 23, 2015
 *      Author: David Hudkins II
 *  Purpose: FeetInches class to hold values for geometric objects
 */

//System Libraries
#include <iostream>
using namespace std;

#ifndef FEETINCHES_H_
#define FEETINCHES_H_

class FeetInches{
private:
	float feet;									//Number of feet
	int inches;									//Number of inches
	void simplify();							//Defined in FeetInches.cpp
public:
	FeetInches();								//Default Constructor

	//Mutator Functions
	void setMeas();								//Set number of feet and inches

	//Accessor Functions
	int getFeet() const{return feet;}	 		//Access feet
	int getInches() const{return inches;}		//Access inches

};

#endif /* FEETINCHES_H_ */
